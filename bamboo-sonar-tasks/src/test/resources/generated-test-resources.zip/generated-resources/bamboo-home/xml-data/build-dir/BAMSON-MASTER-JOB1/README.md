Homepage/Wiki
=============
<http://docs.marvelution.com/display/BAMSON>

Issue Tracker
=============
<http://issues.marvelution.com/browse/BAMSON>

Continuous Builder
==================
<http://builds.marvelution.com/browse/BAMSON>

License
=======
[The Apache Software License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0.txt)
